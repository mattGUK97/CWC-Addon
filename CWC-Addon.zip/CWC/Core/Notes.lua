local ADDON, CWC = ...

-- Release notes shown in the What's New window, newest first. Each item is a line of text, or a table
-- { text, sub = { ... } } for a line with indented details underneath.

CWC.RELEASE_NOTES = {
  {
    version = "0.9.8",
    intro = "Scroll bars throughout CWC, a window that copes with any size, and editable Kill on Sight and Blacklist entries.",
    sections = {
      {
        title = "Highlights",
        items = {
          { text = "Officers and the Guild Master can now edit Kill on Sight and Blacklist entries.", sub = {
            "Click Edit on any entry to fix a typo in the name or change the reason, without removing and re-adding it.",
            "The change goes to everyone in the guild with CWC, and the entry shows who edited it.",
          } },
          { text = "Scroll bars wherever a list can grow.", sub = {
            "Kill on Sight and Blacklist now list every entry, however many there are.",
            "The Roster, the character card's professions, Statistics, Settings and the Raids page all scroll too.",
            "Drag the gold bar, click above or below it, use the arrows or the mouse wheel.",
          } },
        },
      },
      {
        title = "Fixes",
        items = {
          "Resizing the window no longer pushes Settings cards off the bottom. The Tools buttons rearrange to fit the width.",
          "The Tabard page now shows your whole character by default, rather than cutting off the head and feet.",
        },
      },
      {
        title = "Heads up",
        items = {
          "Edits only reach guild mates on 0.9.8 or newer, so please update.",
          "This update adds a new file, so restart the game fully rather than using /reload.",
        },
      },
    },
  },
  {
    version = "0.9.7",
    intro = "The Raid page now shows the WoW: Forever raids and tracks your Onyxia attunement, and there's a new Tabard page to show off the guild colours.",
    sections = {
      {
        title = "Highlights",
        items = {
          { text = "The Raid page is now Raids: Onyxia's Lair, Hyjal Summit and The Barrow Deeps.", sub = {
            "Each raid shows how many players it needs, how many bosses it has and when it opens.",
            "Onyxia's Lair shows whether you're attuned. If you're not, it shows your next step: who to talk to, where they are and what to do.",
            "All 16 steps of the Alliance attunement are listed and ticked off as you finish them.",
            "Guild Attunement lists who in the guild is attuned and who is working on it.",
          } },
          { text = "New Tabard page: the guild tabard in 3D on your own character.", sub = {
            "Drag to turn it, scroll to zoom and right-drag to move it, or use the buttons.",
            "Tick Tabard only to hide your other gear.",
          } },
        },
      },
      {
        title = "Fixes",
        items = {
          "The character card's professions no longer run off the card when the window is short. Scroll the list to see the rest.",
          "High Order Skyborne now has a race icon on the roster and in Statistics.",
        },
      },
      {
        title = "Heads up",
        items = {
          "Raid sign-ups, roles and raid nights are now organised on the guild Discord.",
          "Guild Attunement only shows guild mates who are on this version or newer.",
          "This update adds new files, so restart the game fully rather than using /reload.",
        },
      },
    },
  },
  {
    version = "0.9.6",
    intro = "Adding someone to Kill on Sight now takes a couple of clicks, and the roster can be laid out the way you like.",
    sections = {
      {
        title = "Highlights",
        items = {
          { text = "Add to Kill on Sight from the right-click menu:", sub = {
            "Target a Horde player, right-click their target frame (or focus frame) and choose Add to Kill on Sight.",
            "They're added as a request for the Guild Master or an Officer to approve, with where you spotted them as the reason.",
            "Only shows for Horde players, and won't add someone who's already on the list.",
          } },
          "New Role column on the roster: Guild Master, Officer or Member.",
        },
      },
      {
        title = "New",
        items = {
          { text = "Choose your roster columns with the new Columns button on the Roster page:", sub = {
            "Untick a column to hide it.",
            "Use - and + to change a column's width, or drag the edge of a column heading.",
            "Reset to default puts everything back.",
            "Your choices are saved for you only and don't change anyone else's roster.",
          } },
        },
      },
      {
        title = "Heads up",
        items = {
          "The CWC window opens a little wider by default to fit the new column. If a column doesn't fit, the roster tells you, so you can hide or narrow one.",
          "This update adds a new file, so restart the game fully rather than using /reload.",
        },
      },
    },
  },
  {
    version = "0.9.5",
    intro = "Everyone now sees the latest details for every guild mate, even people you haven't been online with. This update also adds the What's New window you're reading now.",
    sections = {
      {
        title = "Highlights",
        items = {
          { text = "Catch-up when you log in: an online guild mate passes on everything you missed while you were away.", sub = {
            "Other guild mates' latest levels, professions and details, not just the characters of the people online.",
            "Kill on Sight and Blacklist entries, approvals and removals.",
          } },
          "Newest data wins: an older copy of a character's details can never replace a newer one.",
          "Quieter guild channel: one guild mate handles your catch-up instead of everyone at once, and only sends what changed since you last synced.",
          "The character card shows how fresh each character's details are, for example \"Updated 2 hours ago\".",
        },
      },
      {
        title = "New",
        items = {
          { text = "What's New: this window opens once after each update.", sub = {
            "Tick Don't Show on Login to stop it opening by itself.",
            "Open it any time from Settings > Tools > What's New, the What's new button in the CWC header, or /cwc whatsnew.",
          } },
          "Refresh guild data (Settings > Tools) now asks for a full catch-up, not just recent changes.",
        },
      },
      {
        title = "Heads up",
        items = {
          "Catch-up only reaches people on 0.9.5 or later, so guild mates on older versions still need to update. CWC prompts them automatically.",
        },
      },
    },
  },
  {
    version = "0.9.4",
    intro = "More reliable Kill on Sight alerts, with ideas from the Kill on Sight addon by Milestorme.",
    sections = {
      {
        title = "Highlights",
        items = {
          "Visible nameplates are re-checked every few seconds and when you zone in, so a target already on screen is caught.",
          "Each Kill on Sight target alerts once per visit, and again only after 20 seconds out of sight.",
          "A chat reminder, once per session, if enemy nameplates are switched off.",
        },
      },
      {
        title = "Changes",
        items = {
          "Kill on Sight alerts are off in dungeons, raids, battlegrounds and sanctuaries, and only fire for hostile players.",
          "New setting: mute Kill on Sight alerts in neutral goblin towns.",
        },
      },
      {
        title = "Fixes",
        items = {
          "WoW: Forever names written as First-Last are now matched as First Last everywhere: alerts, guild sync and the character scan.",
        },
      },
    },
  },
  {
    version = "0.9.3",
    sections = {
      {
        title = "Highlights",
        items = {
          "The Guild Master and Officers can remove approved Kill on Sight and Blacklist entries.",
          { text = "Blacklist alerts when a blacklisted player contacts you directly:", sub = {
            "a whisper, a group invite, being in your group, a trade window, or mail.",
          } },
          "A tidier, narrower character card that wraps long details instead of cutting them off.",
        },
      },
    },
  },
}
